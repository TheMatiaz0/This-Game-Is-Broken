﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

public class MixerContainer : MonoBehaviour
{
	public AudioMixer Mixer { get; private set; }
}
