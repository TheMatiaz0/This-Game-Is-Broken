﻿using UnityEngine;
using System.Collections;
using Cyberevolver.Unity;
using Cyberevolver;
using System;
using UnityEngine.Events;
using System.Reflection;


public class Example : MonoBehaviour
{
    public int x;
    [Button]
    public void PressMe()
    {

    }
}
public class Mother : MonoBehaviourPlus
{
  
   
}

