﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cyberevolver;
using Cyberevolver.Unity;
using UnityEngine;
using System.Collections;
namespace  Cyberevolver.Unity
{
    public enum UISize
    {
        Default=20,
        SoSmall = 17,
        Small = 22,
        Medium = 40,
        Big = 60,
    }
}
