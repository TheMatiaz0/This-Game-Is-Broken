﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cyberevolver.Unity
{
    public enum AColor
    {
        None,
        White,
        Red,
        Blue,
        Yellow,
        Purple,
        Green,
        Grey,
        Black,
        Clear,
        Cyan
    }
}
