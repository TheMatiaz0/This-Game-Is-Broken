﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cyberevolver.Unity
{
    public enum BackgroundMode
    {
        None=0,
        Box=1,
        GroupBox= 2,
        HelpBox=3,
    }
  
}
