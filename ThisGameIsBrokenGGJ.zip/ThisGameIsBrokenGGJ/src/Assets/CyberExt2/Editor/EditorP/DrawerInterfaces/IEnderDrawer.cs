﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cyberevolver.Unity;
namespace Cyberevolver.EditorUnity
{
    public interface IEnderDrawer:ICyberDrawer
    {
        void DrawEnd(CyberAttrribute atr);
      
       
    }
}
