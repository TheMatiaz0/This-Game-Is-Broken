﻿namespace Cyberevolver
{
   
    [System.Serializable]
    public enum MouseButton
    {
        Left = 0,
        Right = 1,
        Center = 2,
    }
}
