﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using Cyberevolver.Unity;
using Cyberevolver;
public class Test:MonoBehaviourPlus
{

    [SerializeField]
    private Direction dir;

    private void Start()
    {
       
    }
}

